package br.com.industrialdiagnostic

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("industrial_diagnostic", Context.MODE_PRIVATE) }
    private val defaultUrl = "http://192.168.1.100:8000"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 18, 32)
        window.navigationBarColor = Color.rgb(11, 18, 32)
        buildScreen()
        val savedUrl = prefs.getString("server_url", null)
        if (savedUrl.isNullOrBlank()) showServerDialog() else loadServer(savedUrl)
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 18, 32))
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 10, 12, 10)
            setBackgroundColor(Color.rgb(20, 36, 58))
        }
        val title = TextView(this).apply {
            text = "Industrial Diagnostic"
            textSize = 18f
            setTextColor(Color.WHITE)
        }
        val settings = Button(this).apply {
            text = "Servidor"
            setOnClickListener { showServerDialog() }
        }
        toolbar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toolbar.addView(settings)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.allowFileAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url ?: return false
                    return url.scheme != "http" && url.scheme != "https"
                }
            }
            webChromeClient = WebChromeClient()
        }
        layout.addView(toolbar)
        layout.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(layout)
    }

    private fun showServerDialog() {
        val input = EditText(this).apply {
            hint = "http://192.168.1.100:8000"
            setSingleLine(true)
            setText(prefs.getString("server_url", defaultUrl))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(TextView(this@MainActivity).apply {
                text = "Digite o endereço do computador que executa o sistema. Celular e PC precisam estar na mesma rede Wi-Fi."
                textSize = 14f
            })
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Conectar ao sistema")
            .setView(container)
            .setPositiveButton("Conectar") { _, _ ->
                var url = input.text.toString().trim().trimEnd('/')
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://$url"
                if (url.isBlank() || !android.util.Patterns.WEB_URL.matcher(url).matches()) {
                    Toast.makeText(this, "Endereço inválido. Ex.: http://192.168.1.25:8000", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("server_url", url).apply()
                    loadServer(url)
                }
            }
            .setNeutralButton("Usar exemplo") { _, _ ->
                prefs.edit().putString("server_url", defaultUrl).apply()
                loadServer(defaultUrl)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun loadServer(url: String) { webView.loadUrl(url) }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
