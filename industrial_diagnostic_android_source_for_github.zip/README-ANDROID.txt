INDUSTRIAL DIAGNOSTIC — PROJETO ANDROID STUDIO
Identidade visual Perfor | versão 0.3.0

STATUS
Este pacote contém o projeto-fonte Android Studio (Kotlin + WebView), não um APK compilado.
O ambiente em que o pacote foi preparado não possui Android SDK/Gradle e não consegue acessar
os servidores de download necessários para instalar essas ferramentas. Por isso, nenhum APK
foi gerado ou validado aqui.

GERAR O APK NO ANDROID STUDIO
1. Instale o Android Studio em https://developer.android.com/studio
2. Extraia este ZIP em uma pasta local.
3. No Android Studio, escolha Open e selecione a pasta "android-app" (a que contém settings.gradle).
4. Aguarde a sincronização do Gradle. Se solicitado, instale Android SDK Platform 35 e as ferramentas
   de compilação correspondentes pelo SDK Manager.
5. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de depuração normalmente será criado em:
   app/build/outputs/apk/debug/app-debug.apk
7. Use o aviso de conclusão do Android Studio para abrir a pasta do APK.

CONECTAR O APLICATIVO AO PAINEL
1. Execute o sistema no computador Windows usando INICIAR_NO_WINDOWS.bat.
2. Conecte o celular e o computador à mesma rede Wi-Fi.
3. No Windows, execute "ipconfig" e identifique o endereço IPv4 do computador.
4. No aplicativo, toque em "Servidor" e informe, por exemplo:
   http://192.168.1.25:8000
5. Se não conectar, verifique se o Firewall do Windows permite a aplicação na rede privada.

IMPORTANTE
- O aplicativo é uma interface remota: o computador/gateway precisa permanecer ligado.
- O adaptador RS-485 deve estar conectado ao computador/gateway que executa o sistema.
- O conector Mitsubishi FR-D700 deste protótipo é somente leitura; não comanda partida/parada.
- Não exponha o serviço diretamente à internet nem abra a porta para redes públicas.
- Antes de uso industrial real, faça validação técnica, testes de rede e revisão de segurança.
